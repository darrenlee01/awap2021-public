"""
The util class defines the importan enums Color and Shape for passengers,
subways, and stations to use.
"""

from enum import Enum, auto

MAX_TRAINS = 10
SIM_ATTEMPTS = 5
NUM_SHAPES = 8
NUM_COLORS = 10
TRAIN_SPEED = 5
TRAIN_MINIMUM = 0
TRAIN_CAPACITY = 30
SPAWN_DURATION = 5000
SIM_DURATION = 10000

class Shape(Enum):
    CIRCLE = 0
    TRIANGLE = 1
    SQUARE = 2
    OVAL = 3
    PENTAGON = 4
    HEXAGON = 5
    OCTOGON = 6
    DECAGON = 7

class Color(Enum):
    # Use these colors http://www.science.smith.edu/dftwiki/index.php/Color_Charts_for_TKinter
    # THEY MUST BE ONE WORD
    RED = 0
    BLUE = 1
    GREEN = 2
    YELLOW = 3
    PINK = 4
    LIGHTBLUE = 5
    PURPLE = 6
    ORANGE = 7
    SALMON = 8
    GREEN2 = 9


class PassengerStatus(Enum):
    SPAWNED = 1
    ON_TRAIN = 2
    IN_TRANSFER = 3