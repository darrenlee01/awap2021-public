import matplotlib.pyplot as plt
import pandas as pd

class Stats:
    def __init__(self, passenger_log, passenger_spawns, passenger_arrivals, num_trains):
        self._passenger_stats = passenger_log
        self._passenger_spawns = passenger_spawns
        self._passenger_arrivals = passenger_arrivals
        self._num_trains = num_trains
        if self._passenger_stats.empty:
            # Prevent key errors if passneger_log is empty
            self._passenger_stats = pd.DataFrame(columns=[
                'wait_time',
                'travel_time',
                'total_time',
                'num_intermediate_stations',
                'travel_distance',
                'displacement',
                'spawn_time',
                'arrival_time',
                'contains_transfer'])
    
    def get_passenger_log(self):
        """
        Returns a dataframe where each row is an entry for a passenger, and 
        columns are as listed below. 
        NOTE: only includes passengers that reach their final destinations; if a 
        passenger is spawned but never reaches its destination, it is not logged.
        'wait_time': Time from passenger spawn to boarding the train
        'travel_time': Time spent traveling from source to destination
        'total_time': wait_time + travel_time
        'num_intermediate_stations': Number of stations passenger goes 
        through before reaching destination (non-inclusive of start and stop station)
        'travel_distance': Distance passenger travels as it traverses from
        start to stop station along train route, i.e., a sum of the lengths
        of each segment between stations along the passenger's route.
        'displacement': Euclidean distance between start and end stations 
        'spawn_time': Tiemstamp when passenger spawned
        'arrival_time': Timestamp when passenger arrived at destination
        'contains_transfer': Boolean if route contained transfer or not
        """
        return self._passenger_stats
    
    def get_passenger_spawns(self):
        """
        Returns a list, sorted by time of passenger spawn tuples with elements (timestamp, shapeID, spawn stationID).
        Includes all passengers that are spawned.
        """
        return self._passenger_spawns
    
    def get_passenger_arrivals(self):
        """
        Returns a list, sorted by time of passenger spawn tuples with elements (timestamp, shapeID, arrival stationID).
        Includes all passengers that are spawned.
        """
        return self._passenger_arrivals

    # Wait time
    def get_avg_wait_time(self):
        return(self._passenger_stats["wait_time"].mean())
    
    def get_std_wait_time(self):
        return(self._passenger_stats["wait_time"].std())
              
    def get_min_wait_time(self):
        return(self._passenger_stats["wait_time"].min())
               
    def get_max_wait_time(self):
        return(self._passenger_stats["wait_time"].max())

    # Travel Time
    def get_avg_travel_time(self):
        return(self._passenger_stats["travel_time"].mean())
    
    def get_std_travel_time(self):
        return(self._passenger_stats["travel_time"].std())
              
    def get_min_travel_time(self):
        return(self._passenger_stats["travel_time"].min())
               
    def get_max_travel_time(self):
        return(self._passenger_stats["travel_time"].max())
    
    # Total Time
    def get_avg_total_time(self):
        return(self._passenger_stats["total_time"].mean())
    
    def get_std_total_time(self):
        return(self._passenger_stats["total_time"].std())
              
    def get_min_total_time(self):
        return(self._passenger_stats["total_time"].min())
               
    def get_max_total_time(self):
        return(self._passenger_stats["total_time"].max())
    
    # Num intermediate stations
    def get_avg_intermediate_stations(self):
        return(self._passenger_stats["num_intermediate_stations"].mean())
    
    def get_std_intermediate_stations(self):
        return(self._passenger_stats["num_intermediate_stations"].std())
              
    def get_min_intermediate_stations(self):
        return(self._passenger_stats["num_intermediate_stations"].min())
               
    def get_max_intermediate_stations(self):
        return(self._passenger_stats["num_intermediate_stations"].max())

    # Travel Distance
    def get_avg_travel_distance(self):
        return(self._passenger_stats["travel_distance"].mean())
    
    def get_std_travel_distence(self):
        return(self._passenger_stats["travel_distance"].std())
              
    def get_min_travel_distance(self):
        return(self._passenger_stats["travel_distance"].min())
               
    def get_max_travel_distence(self):
        return(self._passenger_stats["travel_distance"].max())
    
    # Displacement
    def get_avg_displacement(self):
        return(self._passenger_stats["displacement"].mean())
    
    def get_std_displacement(self):
        return(self._passenger_stats["displacement"].std())
              
    def get_min_displacement(self):
        return(self._passenger_stats["displacement"].min())
               
    def get_max_displacement(self):
        return(self._passenger_stats["displacement"].max())

    # Number passengers
    def get_num_passengers_served(self):
        return(len(self._passenger_stats))

    def plot_passenger_count(self):
        """
        Plots time unit vs passenger count, where passenger count refers to the number of passengers
        in the system, i.e., passengers that have spawned and are waiting for a train or are in transit.
        Once passengers reach their final destination, they are no longer in the system.
        Returns list of passenger counts, where count[i] is the number of passenger counts at the ith time unit. 
        """
        spawns = [int(t) for (t, _, _) in self._passenger_spawns]
        arrivals = [int(t) for (t, _, _) in self._passenger_arrivals]

        if len(spawns) == 0:
            print("No passengers were spawned")
            return None

        max_time = max(spawns)
        if len(arrivals) != 0:
            max_time = max(max(arrivals), max_time)
        passenger_count = [0]*max_time

        for time in spawns:
            i = int(time)
            for j in range(i, len(passenger_count)):
                passenger_count[j] += 1
        
        for time in arrivals:
            i = int(time)
            for j in range(i, len(passenger_count)):
                passenger_count[j] -= 1
        plt.xlabel("Time")
        plt.ylabel("Number of Passengers")
        plt.title("Number of Passengers Vs Time")
        plt.plot(passenger_count)
        plt.show()
        return passenger_count

    def print_score(self, runtime):
        num_served = self.get_num_passengers_served()
        num_spawned = len(self._passenger_spawns)
        avg_time = self.get_avg_total_time()
        std_time = self.get_std_total_time()
        served_ratio = float(num_served)/float(num_spawned)

        score =  1000.0 * served_ratio - 0.02*(avg_time + std_time) - 30*self._num_trains

        output_string = """ 
        METRIC      // AVG  // STDDEV
        Wait Time   // {} // {}
        Travel Time // {} // {}
        Total Time  // {} // {}
        ----------------------------
        Passengers spawned: {}
        Passengers served: {} 
        Ratio (served/spawned): {}
        Number of trains: {}
        Runtime: {} ms
        Score: {}
         """.format(
             round(self.get_avg_wait_time(), 2),
             round(self.get_std_wait_time(), 2),
             round(self.get_avg_travel_time(), 2),
             round(self.get_std_travel_time(), 2),
             round(self.get_avg_total_time(), 2),
             round(self.get_std_total_time(), 2),
             num_spawned,
             num_served,
             round(served_ratio, 2),
             self._num_trains,
             round(runtime * 1000),
             round(score, 3)
        )
        print(output_string)
        





