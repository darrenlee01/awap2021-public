import matplotlib.pyplot as plt
import pandas as pd

class Stats:
    
    def __init__(self, passenger_stats):
        self._passenger_stats = passenger_stats
    
    # Wait time
    def get_avg_wait_time(self):
        return(self._passenger_stats["wait_time"].mean())
    
    def get_std_wait_time(self):
        return(self._passenger_stats["wait_time"].std())
              
    def get_min_wait_time(self):
        return(self._passenger_stats["wait_time"].min())
               
    def get_max_wait_time(self):
        return(self._passenger_stats["wait_time"].max())

    # Travel Time
    def get_avg_travel_time(self):
        return(self._passenger_stats["travel_time"].mean())
    
    def get_std_travel_time(self):
        return(self._passenger_stats["travel_time"].std())
              
    def get_min_travel_time(self):
        return(self._passenger_stats["travel_time"].min())
               
    def get_max_travel_time(self):
        return(self._passenger_stats["travel_time"].max())
    
    # Total Time
    def get_avg_total_time(self):
        return(self._passenger_stats["total_time"].mean())
    
    def get_std_total_time(self):
        return(self._passenger_stats["total_time"].std())
              
    def get_min_total_time(self):
        return(self._passenger_stats["total_time"].min())
               
    def get_max_total_time(self):
        return(self._passenger_stats["total_time"].max())
    
    # Num intermediate stations
    def get_avg_intermediate_stations(self):
        return(self._passenger_stats["num_intermediate_stations"].mean())
    
    def get_std_intermediate_stations(self):
        return(self._passenger_stats["num_intermediate_stations"].std())
              
    def get_min_intermediate_stations(self):
        return(self._passenger_stats["num_intermediate_stations"].min())
               
    def get_max_intermediate_stations(self):
        return(self._passenger_stats["num_intermediate_stations"].max())

    # Travel Distance
    def get_avg_travel_distance(self):
        return(self._passenger_stats["travel_distance"].mean())
    
    def get_std_travel_distence(self):
        return(self._passenger_stats["travel_distance"].std())
              
    def get_min_travel_distance(self):
        return(self._passenger_stats["travel_distance"].min())
               
    def get_max_travel_distence(self):
        return(self._passenger_stats["travel_distance"].max())
    
    # Displacement
    def get_avg_displacement(self):
        return(self._passenger_stats["displacement"].mean())
    
    def get_std_displacement(self):
        return(self._passenger_stats["displacement"].std())
              
    def get_min_displacement(self):
        return(self._passenger_stats["displacement"].min())
               
    def get_max_displacement(self):
        return(self._passenger_stats["displacement"].max())

    def get_plot(self):
        data = self._passenger_stats
        
        start_time = data["spawn_time"].astype(int)
        travel_time = data["travel_time"].astype(int)
  
        #deciding how long should the passenger count list should be      
        passenger_count = [0]*int(start_time[-1:]+travel_time[-1:]+2)
            
        #increasing passenger count by 1 when a passenger's start time is recorded            
        #increasing passenger count by 1 for the time the passenger travelled and...
        #remained in the system            
        for i,j in zip(start_time,travel_time):
            passenger_count[i]+=1
            for k in range(i+1,i+j+1):
                passenger_count[k]+=1
        
        plt.xlabel("Time")
        plt.ylabel("Number of Passengers")
        plt.title("Number of Passengers Vs Time")
        plt.plot(passenger_count,'ro')
        plt.show()





