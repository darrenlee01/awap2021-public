from tkinter import Tk, Canvas, Frame, BOTH

import time
import math

from .util import Color, TRAIN_CAPACITY, TRAIN_MINIMUM
from .simulation.event import EventType

class Point:
    """convenience for point arithmetic"""
    def __init__(self, x, y):
        self.x, self.y = x, y
    def __add__(self, other):
        return Point(self.x + other.x, self.y + other.y)
    def __iter__(self):
        yield self.x
        yield self.y



# Time betwen animations
class Visualization(Frame):
    @staticmethod
    def GetDistance(coord1,coord2):
        return math.sqrt((coord1[0] - coord2[0]) ** 2 + (coord1[1] - coord2[1]) ** 2)

    @staticmethod
    def FindMidPoint(coord1, coord2):
        return ((coord1[0] + coord2[0]) / 2, (coord1[1] + coord2[1]) / 2)

    @staticmethod
    def OnSide(coord1,coord2):
        coord3 = (coord1[0], coord2[1])  # bottom left
        sideLen = Visualization.GetDistance(coord3, coord2)
        topLen = Visualization.GetDistance(coord3, coord1)
        return sideLen <= topLen

    @staticmethod
    def remapStations(stationData):
        stations = {
            0: (0, 0),
        }
        for coord in stationData:
            id = stationData[coord][0]
            stations[id] = coord
        return stations


    @staticmethod 
    def map(n, oMin, oMax, nMin, nMax):
        OldRange = (oMax - oMin)
        NewRange = (nMax - nMin)
        return (((n - oMin) * NewRange) / OldRange) + nMin

    def __init__(self, parent, width, height, board, states_list, speed=1):
        super().__init__()
        self.speed = speed
        self.debug = False
        self.parent = parent


        self.size = (width, height)

        self.states_list = states_list  # game state
        #self.board = board
        self.stationData = board['station_locations']  # original backend station loc: (id, shape) dict
        self.network = board['network']  # network is color : [stations]
        self.stations = self.remapStations(self.stationData)  # Mystation id: coords dict

        ##########################
        self.MIN_SHAPE_SIZE = 18 #smallest shape size
        self.MAX_SHAPE_SIZE = 30 #max shape size
        self.MAX_PASSENGER_AT_STATION = 400 # used for scaling shapes
        self.shapeSize = self.MIN_SHAPE_SIZE
        self.TRAIN_SHAPE_SIZE = 12
        self.trackSize = 4
        ########Train objects for anims############
        self.prevEvent = EventType.SPAWN
        self.canvas = Canvas(self)

        self.constructor()

    def drawCircle(self,coord, size, color="white"):
        x1 = coord[0] - size
        x2 = coord[0] + size
        y1 = coord[1] - size
        y2 = coord[1] + size
        self.canvas.create_oval(x1, y1, x2, y2,fill=color,width=3)
        return
    
    def drawOval(self,coord, size, color="white"):
        x1 = coord[0] - 2*size
        x2 = coord[0] + 2*size
        y1 = coord[1] - size
        y2 = coord[1] + size
        self.canvas.create_oval(x1, y1, x2, y2,fill=color,width=3)

    def drawSquare(self, coord, size, color="white"):
        x1 = coord[0] - size
        x2 = coord[0] + size
        y1 = coord[1] - size
        y2 = coord[1] + size
        self.canvas.create_rectangle(x1, y1, x2, y2,fill=color,width=3)
        return

    def drawTriangle(self, coord, size, color="white"):
        x1 = coord[0]
        x2 = coord[0] + size
        x3 = coord[0] - size
        y1 = coord[1] - size
        y2 = coord[1] + size
        y3 = coord[1] + size
        self.canvas.create_polygon(x1, y1, x2, y2, x3, y3,fill=color) #this doesn't display a border for some reason
        self.canvas.create_line(x1,y1,x2,y2, width=3)
        self.canvas.create_line(x2, y2, x3, y3, width=3)
        self.canvas.create_line(x1, y1, x3, y3, width=3)
        return
    
    def drawRegularPolygon(self, num_sides, bbox_side, x, y, color="white"):   # x, y are bbox center canvas coordinates
        side_length = 2 * (bbox_side // 2) * math.sin(math.pi / num_sides)

        apothem = side_length / (2 * math.tan(math.pi / num_sides))
        points = [Point(x - side_length // 2, y - apothem)]
        
        # Make points
        _angle = 2 * math.pi / num_sides
        for pdx in range(num_sides):
            angle = _angle * pdx
            _x = math.cos(angle) * side_length
            _y = math.sin(angle) * side_length
            points.append(points[-1] + Point(_x, _y))

        lines = []
        # Make lines
        for p0, p1 in zip(points[:-1], points[1:]):
            lines.append((*p0, *p1))
        
        # Draw 
        for line in lines:
            self.canvas.create_line(line, width=3)

        points_list = []
        for p in points:
            points_list.append(p.x)
            points_list.append(p.y)
        self.canvas.create_polygon(points_list,fill=color)

    def drawPentagon(self, coord, size, color="white"):
        self.drawRegularPolygon(5, 2*size, coord[0], coord[1])
        return
    
    def drawHexagon(self, coord, size, color="white"):
        self.drawRegularPolygon(6, 2*size, coord[0], coord[1])
        return
    
    def drawOctogon(self, coord, size, color="white"):
        self.drawRegularPolygon(8, 2*size, coord[0], coord[1])
        return

    def drawDecagon(self, coord, size, color="white"):
        self.drawRegularPolygon(10, 2*size, coord[0], coord[1])
        return

    def findColors(self,color):
        EColor = Color(color)
        if EColor in Color:
            colorName = EColor.name.lower()
        else:
            raise RuntimeError("Undefined train color. Please make sure you are using less than MAX_TRAINS trains")
        return colorName

    def drawStations(self, stationData, stationPassengers):
        for station in self.stations:
            amount = len(stationPassengers[station])
            self.shapeSize = self.map(amount, 0, self.MAX_PASSENGER_AT_STATION, self.MIN_SHAPE_SIZE, self.MAX_SHAPE_SIZE)
            coord = self.stations[station]
            stationInfo = stationData[coord]
            if stationInfo[1] == 0:  # CIRCLE station
                self.drawCircle(coord, self.shapeSize)
            elif stationInfo[1] == 1:  # TRIANGLE station
                self.drawTriangle(coord, self.shapeSize)
            elif stationInfo[1] == 2:  # SQUARE station
                self.drawSquare(coord, self.shapeSize)
            elif stationInfo[1] == 3: # OVAL station
                self.drawOval(coord, self.shapeSize)
            elif stationInfo[1] == 4: # PENTAGON station
                self.drawPentagon(coord, self.shapeSize)
            elif stationInfo[1] == 5: # HEXAGON station
                self.drawHexagon(coord, self.shapeSize)
            elif stationInfo[1] == 6: # OCTOGON station
                self.drawOctogon(coord, self.shapeSize)
            elif stationInfo[1] == 7: # DECAGON station
                self.drawDecagon(coord, self.shapeSize)
            else:
                raise RuntimeError("Undefined station shape.")
            if self.debug: print("Station " + str(stationInfo[0]) + " is " + str(stationInfo[1]))
        return

    def drawRail(self, coord1, coord2, color="black"):
        self.canvas.create_line(coord1[0], coord1[1], coord2[0], coord2[1], fill=color, width=self.trackSize)
        return

    def drawRails(self, stations, network):
        for color in network: #station ID  maps to color of rail.
            colorName = self.findColors(color)
            stops = network[color]
            for i in range(len(stops) - 1):
                self.drawRail(stations[stops[i]], stations[stops[i +1]],colorName)
        return

    def drawProgressBar(self, coord1, coord2, val, fullColor= "black", emptyColor = "white", borderColor = "black", borderThickness = 5):
        bar = self.canvas.create_rectangle(coord1[0], coord1[1], coord2[0], coord2[1], fill=emptyColor, outline=borderColor, width=borderThickness)
        coord3 = (coord1[0], coord2[1])  #bottom left
        #are we on side
        if not self.OnSide(coord1,coord2):
            #basically drawing these things ||
            topLen = self.GetDistance(coord3,coord2)
            fillVal = int(self.map(val, 0, 1, 0, topLen))
            for i in range(fillVal):
                self.canvas.create_line(coord1[0] + i, coord1[1], coord1[0] + i, coord2[1], fill=fullColor)
        else:
            sideLen = self.GetDistance(coord3,coord1)
            #basically drawing these things --
            fillVal = int(self.map(val, 0, 1, 0, sideLen))
            for i in range(fillVal): #MLK TODO flip this around so it draws left-wards not right-wards,
                self.canvas.create_line(coord1[0], coord1[1] + i, coord2[0] , coord1[1] + i, fill=fullColor)
        return bar

    #def drawProgessBar(self, coord1, coord2, val):

    def remapStationPassengers(self, Iter):
        PassengerStations = self.states_list[Iter]['stations']
        stations = {
            0: [], #ID : Passengers going to a Station ID
        }
        for PassengerStation in PassengerStations:
            stations[PassengerStation[0]] = PassengerStations[PassengerStation]
        return stations


    def refreshStationPassengers(self, stationPassengers):
        for stationPassenger in self.stations:
            x1 = self.stations[stationPassenger][0]
            y1 = self.stations[stationPassenger][1]
            amount = len(stationPassengers[stationPassenger])
            self.canvas.create_text(x1,y1,text=str(amount)) #MLK TODO: On a triangle we need to lower this number down a little bit.

    def drawNetwork(self,iter):
        stationPassengers = self.remapStationPassengers(iter)
        self.drawRails(self.stations, self.network)
        self.drawStations(self.stationData, stationPassengers)
        self.refreshStationPassengers(stationPassengers)
        return

    def createTrainCoords(self, coord, coord2):
        if self.OnSide(coord, coord2):
            coord1 = coord[0] - self.TRAIN_SHAPE_SIZE, coord[1] - self.TRAIN_SHAPE_SIZE * 2
            coord2 = coord[0] + self.TRAIN_SHAPE_SIZE, coord[1] + self.TRAIN_SHAPE_SIZE * 2
        else:
            coord1 = coord[0] - self.TRAIN_SHAPE_SIZE * 2, coord[1] - self.TRAIN_SHAPE_SIZE
            coord2 = coord[0] + self.TRAIN_SHAPE_SIZE * 2, coord[1] + self.TRAIN_SHAPE_SIZE
        return coord1, coord2

    def makeTrains(self, frame): #distanceAlongTrack : 0 (src), 1 (midpoint), 2 (dest)
        trains = self.states_list[frame]['trains']
        currEvent = self.states_list[frame]['event']
        for train in trains: #for now we shall render the train between stations...
            DestCheck = trains[train]['src']
            if DestCheck == None: continue


            # Get coords to where we're going  from stations dictionary
            DestCoord1 = self.stations[trains[train]['src']]
            DestCoord2 = self.stations[trains[train]['dest']]


            # Calculate our orientation
            if currEvent['train'] == train:
                if currEvent['typ'] == EventType.ARRIVAL:
                    coord1, coord2 = self.createTrainCoords(DestCoord2, DestCoord1)  #dest
                elif currEvent['typ'] == EventType.DEPARTURE:
                    coord1, coord2 = self.createTrainCoords(DestCoord1, DestCoord2)  # src
            else: # in transit if we're not arriving, departing we're
                # Get the midpoint of where we are...
                midPoint = self.FindMidPoint(DestCoord1, DestCoord2)
                coord1, coord2 = self.createTrainCoords(midPoint, DestCoord2) #in between src and dest

            passengers = len(trains[train]['passengers'])
            val = self.map(passengers, 0, TRAIN_CAPACITY*TRAIN_CAPACITY,
                           TRAIN_MINIMUM, TRAIN_CAPACITY)  # percent to fill the train block
            #get train color from netwoork color
            TrainColor = self.findColors(train)
            self.drawProgressBar(coord1,coord2, val, fullColor=TrainColor)
        return

    def drawFrame(self, frame):
        self.pack(fill=BOTH, expand=1)  # need this here other wise the shapes won't appear.
        self.drawNetwork(frame)
        self.canvas.pack(fill=BOTH, expand=1)  # Need this here or shapes won't appear.
        return


    def redrawBackground(self, frame):
        self.canvas.delete("all")  # clears canvas
        self.drawFrame(frame)

    def runEvent(self, frame, delay):
        event_type = self.states_list[frame]['event']['typ']
        # print(frame, event_type, self.states_list[frame]['event'], "prev event:", self.prevEvent)
        time.sleep(delay)
        self.redrawBackground(frame)
        self.redrawBackground(frame)
        self.makeTrains(frame)
        self.parent.update()
        self.prevEvent = event_type

    def constructor(self):
        self.master.title("AWAP Simulation")  # name of window
        self.master.geometry(str(self.size[0]) + "x" + str(self.size[1]))  # set resolution of TK window
        return

    def run(self):
        # print("Number of states", len(self.states_list))
        for frame in range(len(self.states_list)):
            if self.states_list[frame]['event']['typ'] != EventType.SPAWN:
                self.runEvent(frame, 1/self.speed)
            #else:
                #print("SPAWN", self.states_list[frame]['event']['time'])
        # print("Finished running visualization")
        self.parent.destroy()


