"""
The Train class stores the passengers on this
current train, its color.
"""
from ..util import TRAIN_CAPACITY

class Train:
    def __init__(self, riders, color):
        self.riders = set(riders)
        self.color = color
        self.src = None
        self.dest = None
    

    def get_passengers_arrived(self, station):
        """ 
        Get passengers that the should exit train at the station
        Returns tuple of (arrived_passengers, transferring_passengers)
        """
        arrived_passengers = set()
        transferring_passengers = set()
        for passenger in self.riders:
            if passenger.is_arrived(station):
                if passenger.is_transfer():
                    # Update the passenger's current_route to only include 2nd train ride.
                    passenger.complete_transfer()
                    transferring_passengers.add(passenger)
                else:
                    arrived_passengers.add(passenger)
        return (arrived_passengers, transferring_passengers)
    
    def log_visited_station(self, stationID):
        """
        For each passenger, add stationID to its visited list.
        """
        for p in self.riders:
            p.add_visited_station(stationID)


    def get_num_available_seats(self):
        """
        Returns number of passengers that can board the train, by 
        subtracting number of riders from TRAIN_CAPACITY
        """
        return TRAIN_CAPACITY - len(self.riders)
    
    def add_riders(self, riders_to_add):
        if len(riders_to_add) + len(self.riders) > TRAIN_CAPACITY:
            raise RuntimeError("Cannot add riders to train, number of riders would exceed train capacity")
        self.riders = self.riders.union(riders_to_add)
    
    def remove_riders(self, riders_to_rem):
        self.riders = self.riders - riders_to_rem
    
    def set_src_dest(self, src, dest):
        self.src = src
        self.dest = dest
