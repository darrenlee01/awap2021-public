"""
This file defines the Passenger class. The class stores its shape and an ID.
"""
import queue
import numpy as np

class Passenger:
    def __init__(self, shape, spawn_loc, spawn_time):
        """
        shape (int)
        spawn_loc (int): Station ID of passenger's starting location
        """
        self.shape = shape
        self.spawn_loc = spawn_loc
        self.routes = []
        self.current_route = None

        # The following member variables are used for logging stats.
        self.spawn_time = spawn_time 
        self.contains_transfer = None # Boolean, defaults to false
        self.depart_time = None # Timestamp the passenger leaves its spawn station
        self.transfer_arrival_time = None # Timestamp the passenger arrives at transferring station, if applicable
        self.transfer_departure_time = None # Timestamp the passenger leaves transferring station, if applicable
        self.arrival_time = None # Timestamp the passenger arrives at final destination station
        self.visited_stations = [spawn_loc] # List of station IDs of intermediate stations the passenger passes through. Includes source and destination stations.

    def find_route(self, adjacency_list, station_shapes, cache):
        """
        A route is considered valid if it takes the passenger from its current station to a station of its shape in one
        or fewer connections.
        :param station_shapes: List of station_shapes, indexed by station ID
        :param adjacency_list: Representation of the network graph
        :return: List of valid routes, where list elements are tuples
        If transfer is not required, (destination station ID, color of line)
        If transfer required, (transfer station ID, color of 1st line, destination station ID, color of 2nd line)
        """
        # prefer cache if exists
        if (self.spawn_loc, self.shape) in cache:
            self.routes = cache[(self.spawn_loc, self.shape)]
            return

        # Queue elements are tuples,
        # If transfer not required, (current station ID, color)
        # If transfer required, (transfer station ID, color1, current station ID, color2)
        q = queue.Queue()
        # Put all of the neighbors of the current station on the queue
        for n in adjacency_list[self.spawn_loc]:
            (st, distance, color) = n
            q.put((st, color))

        valid_routes = []
        visited = set()
        while not q.empty():
            node = q.get()
            visited.add(node)

            # The station shape is the same as the destination, so add node to list of valid routes
            if len(node) == 2 and station_shapes[node[0]] == self.shape:
                valid_routes.append(node)
            if len(node) == 4 and station_shapes[node[2]] == self.shape:
                valid_routes.append(node)

            if len(node) == 4:
                neighbors = adjacency_list[node[2]]
            else:
                neighbors = adjacency_list[node[0]]

            for n in neighbors:
                (n_station, distance, n_color) = n
                # Determine if a transfer is needed
                if len(node) == 4 and node[3] == n_color:
                    # A transfer has already occurred and the edge is the same color as 2nd line
                    new_node = (node[0], node[1], n_station, node[3])
                    if new_node not in visited:
                        q.put(new_node)
                elif len(node) == 2 and node[1] == n_color:
                    # A transfer has not yet occurred and the edge is the same color as 1st line
                    new_node = (n_station, node[1])
                    if new_node not in visited:
                        q.put(new_node)
                elif len(node) == 2:
                    # Passenger will transfer at node to get the neighbor n
                    new_node = (node[0], node[1], n_station, n_color)
                    if new_node not in visited:
                        q.put(new_node)
        self.routes = valid_routes

        # cache the pathfind route
        cache[(self.spawn_loc, self.shape)] = valid_routes

    def set_route(self, route):
        self.current_route = route
        self.contains_transfer = self.is_transfer()

    def set_depart_time(self, timestamp):
        if self.current_route is None:
            raise RuntimeError("Cannot set depart time of passenger without current route set.")
        if self.contains_transfer:
            if self.is_transfer():
                # Transfer has not been completed yet; current route still contains transfer
                self.depart_time = timestamp
            else:
                self.transfer_departure_time = timestamp
        else:
            self.depart_time = timestamp
    
    def set_arrive_time(self, timestamp):
        self.arrival_time = timestamp
    
    def set_transfer_arrive_time(self, timestamp):
        self.transfer_arrival_time = timestamp

    def is_arrived(self, station):
        return self.current_route[0] == station

    def is_transfer(self):
        return len(self.current_route) == 4

    def add_visited_station(self, stationID):
        self.visited_stations.append(stationID)

    def complete_transfer(self):
        if not self.is_transfer():
            raise RuntimeError("Passenger's current route does not include a transfer, cannot complete transfer")
        else:
            self.current_route = (self.current_route[2], self.current_route[3])

    def get_log(self, stations):
        """
        stations: is a list where station[stationID] = (x, y) location
        """
        if self.depart_time is None or self.arrival_time is None or self.is_transfer is None:
            raise RuntimeError("Passenger has missing attributes, cannot generate log")

        wait_time = self.depart_time - self.spawn_time
        travel_time = self.arrival_time - self.depart_time
        total_time = self.arrival_time - self.spawn_time
        num_intermediate_stations = len(self.visited_stations) - 2 # Exclude source and dest stations

        travel_distance = 0
        for i in range(len(self.visited_stations) - 1):
            x1, y1 = stations[self.visited_stations[i]] # Start point of segment
            x2, y2 = stations[self.visited_stations[i + 1]] # End point of segment
            travel_distance += np.linalg.norm([y1-y2, x1-x2])

        x1, y1 = stations[self.visited_stations[0]]
        x2, y2 = stations[self.visited_stations[-1]]
        displacement = np.linalg.norm([y1-y2, x1-x2])

        log = {
            'wait_time': wait_time,
            'travel_time': travel_time,
            'total_time': total_time,
            'num_intermediate_stations': num_intermediate_stations,
            'travel_distance': travel_distance,
            'displacement': displacement,
            'spawn_time': self.spawn_time,
            'arrival_time': self.arrival_time,
            'shape': self.shape
        }

        if self.contains_transfer:
            log['contains_transfer'] = True
            log['transfer_wait_time'] = self.transfer_departure_time - self.transfer_arrival_time
            log['first_leg_travel_time'] = self.transfer_arrival_time - self.spawn_time
            log['second_leg_travel_time'] = self.arrival_time - self.transfer_departure_time
        else:
            log['contains_transfer'] = False
            log['transfer_wait_time'] = 0
            log['first_leg_travel_time'] = 0 
            log['second_leg_travel_time'] = 0

        return log