"""
The Simulation class handles how the game is simulated. It keeps an event
queue and stores the set of subways and passengers, which constantly gets
updated as we proceed through the event queue.
"""

import queue
import pdb
import pandas as pd

from ..board import Board
from ..util import NUM_SHAPES, TRAIN_SPEED, SPAWN_DURATION
from .station import Station
from .event import EventType
from .train import Train
from .event import PassengerEvent, ArrivalEvent, DepartureEvent
from .passenger import Passenger


class Simulation:
    def __init__(self, board: Board, start_time: int, duration: int):
        """
        __init__ constructs a PQ for our event queue, and populates it with
        passenger spawns and arrival/departure times.
        The PQ is ordered by time of event. See simulation/event.py for 
        description of event types.
        """
        self.pq = queue.PriorityQueue()
        self.stations = {}
        self.trains = {}
        self.passenger_log = []

        # Fill PQ with passenger spawn events for each station
        for station_id in range(board.num_stations):
            self.stations[station_id] = Station(
                station_id, 
                board.station_shapes[station_id],
                board.station_locations[station_id][0],
                board.station_locations[station_id][1],
                board.station_dist_mean[station_id]
            )
            station_spawn_events = self.stations[station_id].spawn_passengers(
                start_time,
                SPAWN_DURATION,
                NUM_SHAPES
            )
            for event in station_spawn_events:
                self.pq.put(event)

        # Create arrivals and departures for trains
        for train_color, stations_list in board.network.items():
            time = 0
            # Create first event for the train
            init_event = ArrivalEvent(time, train_color, stations_list[0], stations_list[1])
            from_station = stations_list[0]
            this_station = stations_list[1]
            self.pq.put(init_event)
            while time < duration:
                # Create the departure event 
                time += 1
                next_station = board.get_next_station(train_color, from_station, this_station)
                dep_event = DepartureEvent(time, train_color, this_station, next_station)
                self.pq.put(dep_event)
                
                #if train_color == 1:
                    #print("From station {}, This station{}, Next station {}".format(from_station, this_station, next_station))
                # Compute the travel time to the next station
                travel_time = max(1, int(board.get_stations_distance(this_station, next_station)/TRAIN_SPEED))
                time += travel_time

                # Create the arrival event
                arrival_event = ArrivalEvent(time, train_color, this_station, next_station)
                self.pq.put(arrival_event)
                
                
                from_station = this_station
                this_station = next_station

            # Create train object 
            self.trains[train_color] = (Train([], train_color))
        self.board = board

    def run(self):
        """ run keeps popping from the PQ and handles the given event. 
        Returns list of states, and a dataframe of passenger states. 
        Elements in the states list are a dictionary with this 
        shape. Any ID will be an int. 
            'event': dictionary containting event info
                {
                    'typ': Event Type
                    'time': (int) Time step
                    
                    (arrival/departure events only)
                    'train': Train color ID 
                    'src': Source station ID
                    'dest': Destination station ID

                    (passenger event only)
                    'location': Spawn station ID 
                    'shape': Shape ID
                }
            'station': dictionary mapping (station ID, station shape ID) -> [list of passenger shape IDs]
            'trains': ditionary mapping train_color_ID -> dictionary {
                    'src': stationID,
                    'dest': stationID,
                    'passengers': [list of passenger shape IDs]
                }

        Rows of the dataframe represent each passenger
        Columns in the dataframe are:
            'wait_time': Time from passenger spawn to boarding the train
            'travel_time': Time spent traveling from source to destination
            'total_time': wait_time + travel_time
            'num_intermediate_stations': Number of stations passenger goes 
            through before reaching destination (non-inclusive of start and stop station)
            'travel_distance': Distance passenger travels as it traverses from
            start to stop station along train route, i.e., a sum of the lengths
            of each segment between stations along the passenger's route.
            'displacement': Euclidean distance between start and end stations 
            'spawn_time': Tiemstamp when passenger spawned
            'arrival_time': Timestamp when passenger arrived at destination
            'contains_transfer': Boolean if route contained transfer or not
            (below only apply if contains_transfer)
            'transfer_wait_time': Time between arriving at transfer station on
            1st train and leaving transfer station on 2nd train
            'first_leg_travel_time': Time spent on the 1st train
            'second_leg_travel_time': Time spent on the 2nd train
        """
        states = []
        while not self.pq.empty():
            newEvent = self.pq.get()
            #print(newEvent.__dict__)
            self.handleEvent(newEvent)
            current_state = self.getState()
            current_state['event'] = newEvent.__dict__
            states.append(current_state)
        
        passenger_stats = self.computePassengerStats()
        return states, passenger_stats
    
    def getState(self):
        stationsState = {(id, station.shape): [p.shape for p in station.passengers] for (id, station) in self.stations.items()}
        trainsState = {id: 
            {   
                "src": train.src, 
                "dest": train.dest,
                "passengers": [p.shape for p in train.riders] 
            } for (id, train) in self.trains.items()
        } 
        state = {
            "stations": stationsState,
            "trains": trainsState, 
        }
        return state

    def handleEvent(self, event):
        """ handleEvent executes actions on the game state given the event. """
        if event.typ == EventType.SPAWN:
            # Create a passenger object and add to Station
            new_passenger = Passenger(event.shape, event.loc, event.time)
            new_passenger.find_route(self.board.get_adjacency_list(), self.board.station_shapes)
            self.stations[event.loc].add_passenger(new_passenger)
        elif event.typ == EventType.DEPARTURE:
            # Get number of available seats on the train
            num_passengers = self.trains[event.train].get_num_available_seats()
            # Get passengers that should board the train
            passengers = self.stations[event.src].get_passengers_for_train(event.train, num_passengers)
            # Move passengers onto the train
            self.trains[event.train].add_riders(passengers)
            # Remove passengers from station
            self.stations[event.src].remove_passengers(passengers)
            # Set Train's src/dest
            self.trains[event.train].set_src_dest(event.src, event.dest)
            # Set passengers departure time
            for p in passengers:
                p.set_depart_time(event.time)
        elif event.typ == EventType.ARRIVAL:
            # Log the arrival for each passenger
            self.trains[event.train].log_visited_station(event.dest)
            # Get passengers that should get off the train
            (arrived_passengers, transfer_passengers) = self.trains[event.train].get_passengers_arrived(event.dest)
            # Remove passengers from train
            self.trains[event.train].remove_riders(arrived_passengers)
            self.trains[event.train].remove_riders(transfer_passengers)
            # Add transfering passengers to station
            self.stations[event.dest].add_passengers(transfer_passengers)
            self.trains[event.train].set_src_dest(event.src, event.dest)
            # Set passengers arrival time
            for p in arrived_passengers:
                p.set_arrive_time(event.time)
                self.passenger_log.append(p.get_log(self.board.station_locations))
            for p in transfer_passengers:
                p.set_transfer_arrive_time(event.time)
        # print(self.getState())

    def computePassengerStats(self):
        df = pd.DataFrame(self.passenger_log)
        return df
        #print(df)
