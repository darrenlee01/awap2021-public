import math
import numpy as np
from collections import defaultdict
from .util import MAX_TRAINS

class Board:

    def __init__(self, num_stations, station_locations, station_shapes, station_dist_mean):
        """
        :param station_locations: list of (x, y) tuples for corresponding [station0, station1, ...]
        :param station_shapes: list of Shape corresponding [station0, station1 ...]
        :param station_dist_mean: list of distribution means for passenger arrival corresponding [station0, station1, ...]
        """
        if(len(station_locations) != num_stations):
            raise RuntimeError("Invalid board file. There should be {} stations but only {} station locations are listed".format(
                num_stations, len(station_locations)))
        if(len(station_shapes) != num_stations):
            raise RuntimeError("Invalid board file. There should be {} stations but only {} station shapes are listed".format(
                num_stations, len(station_shapes)))
        if(len(station_dist_mean) != num_stations):
            raise RuntimeError("Invalid board file. There should be {} stations but only {} station distributions are listed".format(
                num_stations, len(station_dist_mean)))

        self.cache = {}
        self.num_stations = num_stations
        self.station_locations = station_locations
        self.station_shapes = station_shapes
        self.station_dist_mean = station_dist_mean
        self.network = None
        self.adjacency_list = None
    
    def set_network(self, network):
        """
        :param network: a dictionary that maps a color c to a list [id0, id1, ...], where the
        list is a list of subway station UIDs that are on this line.
        :return: boolean True if valid network
        """
        self.network = network
        return self.check_valid_network()

    def check_valid_network(self):
        """
        The list is valid if each UID represents a valid subway
        station, and the list either contains no duplicates or only has one
        duplicate station at the beginning and end of the list, in which case
        the line is a loop.
        :return: boolean True if valid
        """
        if self.network is None:
            raise RuntimeError("Network not set in Board")
        
        train_list = list(self.network.keys())
        if len(train_list) > MAX_TRAINS:
            raise RuntimeError("Number of trains in network exceeded MAX_TRAINS. There can be at most {} trains, this network contains {}".format(MAX_TRAINS, len(train_list)))
        
        train_arr = np.array(train_list)
        all_trains_valid = np.all(train_arr >= 0) and np.all(train_arr < MAX_TRAINS)
        if not all_trains_valid:
            raise RuntimeError("Invalid train number (trains must be numbered from 0 to MAX_TRAINS-1)")

        for color, station_list in self.network.items():
            if not len(station_list) > 1:
                raise RuntimeError("Lines must connect at least 2 stations")
            all_unique = len(np.unique(station_list)) == len(station_list)
            cycle_unique = len(np.unique(station_list[1:-1])) == len(station_list[1:-1])
            is_valid_cycle = (cycle_unique and station_list[0] == station_list[-1])
            station_arr = np.array(station_list)
            all_stations_valid = np.all(station_arr >= 0) and np.all(station_arr < self.num_stations)
            if not (all_unique or is_valid_cycle):
                raise RuntimeError("Lines can only be simple cycles or paths")
            if not all_stations_valid:
                raise RuntimeError("Invalid subway station (stations must be numbered from 0 to n-1)")
        return True

    def get_adjacency_list(self):
        """
        :return: Network graph in the form of a dictionary of where key = station,
        value = (station, distance, color) list
        """
        if self.network is None:
            raise RuntimeError("Network not set in Board")

        if self.adjacency_list is None:
            adjacency_list = defaultdict(list) #dict.fromkeys(np.arange(self.num_stations), [])                
            for color, station_list in self.network.items():
                for i in range(len(station_list) - 1):
                    s1 = station_list[i]
                    s2 = station_list[i+1]
                    adjacency_list[s1].append((s2, self.get_stations_distance(s1, s2), color))
                    adjacency_list[s2].append((s1, self.get_stations_distance(s1, s2), color))
            self.adjacency_list = adjacency_list
        
        return self.adjacency_list

    def is_cycle(self, color: int):
        if self.network is None:
            raise RuntimeError("Network not set in Board")
        station_list = self.network[color]
        return station_list[0] == station_list[-1]

    def get_next_station(self, color: int, from_station: int, this_station: int):
        """
        from_station--->this_station--->to station
        Get the next station, which can't be the station its coming from
        :param color:
        :param from_station: UID
        :param this_station: UID
        :return: to_staion UID
        """
        if self.network is None:
            raise RuntimeError("Network not set in Board")

        station_list = np.array(self.network[color])
        try:
            this_idx = np.where(station_list == this_station)[0][0]
        except KeyError:
            raise RuntimeError("Could not find station {} in train color {}'s station list".format(this_station, color))
        if self.is_cycle(color):
            # Cycles will run in increasing index direction
            if this_idx == len(station_list) - 2:
                # Last non-repeated station in the cycle
                return station_list[0]
            else:
                return station_list[this_idx + 1]
        else:
            try:
                from_idx = np.where(station_list == from_station)[0][0]
            except IndexError:
                raise RuntimeError("Cannot find matching station in get_next_station.")
            #if color == 1:
                #pdb.set_trace()
            if this_idx == 0:
                # Reached the front of the line, turn around
                return station_list[1]
            elif this_idx == len(station_list) - 1:
                # Reached the end of the line, turn around
                return station_list[this_idx - 1]
            elif from_idx < this_idx:
                # Traversing in the "forwards" direction
                return station_list[this_idx + 1]
            else:
                # Traversing in the "backwards" direction
                return station_list[this_idx - 1]

    def get_stations_distance(self, station_1, station_2):
        x1, y1 = self.station_locations[station_1]
        x2, y2 = self.station_locations[station_2]
        return np.linalg.norm([y1-y2, x1-x2])
