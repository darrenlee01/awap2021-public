import setuptools

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setuptools.setup(
    name="awap-2021", # Replace with your own username
    version="0.0.1",
    author="ACM@CMU",
    author_email="acm-exec@andrew.cmu.edu",
    description="Game for Algorithms with a Purpose 2021, Commute Ch",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://awap2021.com",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)