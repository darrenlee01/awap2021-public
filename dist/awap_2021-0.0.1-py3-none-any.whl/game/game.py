# External imports
import sys
import yaml
import pandas as pd
import tkinter as tk

# Internal imports
from .board import Board
from .simulation.simulate import Simulation
from .util import SIM_ATTEMPTS, SIM_DURATION
from .stats import Stats
from .visualization import Visualization

class Game:
    TICK_RATE = 1 / 60

    def __init__(self, board_file):
        """
        board_file: Path to the board that the current instance will simulate
        the game on.
        """

        self.board = self._parse(board_file)

        # We allow players to try simulation maximum of 4 times
        self._sim_count = 0

        # Used to save info for visualization
        self.board_info = None
        self.states_list = None

    def _parse(self, file):
        """
        _parse parses the given file into a Board class and stores it.
        file: Path to the board file to parse.
        """
        with open(file, 'r') as board_file:
            board_content = yaml.load(board_file, Loader=yaml.FullLoader)
            board = Board(
                board_content['num_stations'],
                board_content['station_locations'],
                board_content['station_shapes'],
                board_content['station_dist_mean']
            )
            return board
        raise RuntimeError("Could not parse board") #pycharm says this code is unreachable

#    def GetTickRate(self):
#       return TICK_RATE

    def getStationLocations(self):
        """
        Returns a dictionary that
        maps a location (x, y) to a tuple (i, s), where i is the UID of the
        station at location (x, y), and s is the shape of the station
        """
        locations = [(loc[0], loc[1]) for loc in self.board.station_locations]
        shapes = self.board.station_shapes
        uids = range(len(shapes))

        values = zip(uids, shapes)

        return dict(zip(locations, values))

    def simulate(self, network):
        """
        simulate takes in a network specified by the player, which is a
        dictionary that maps a color c to a list [id0, id1, ...], where the
        list is a list of subway station UIDs that are on this line. The list
        must be valid; the list is valid if each UID represents a valid subway
        station, and the list either contains no duplicates or only has one
        duplicate station at the beginning and end of the list, in which case
        the line is a loop.

        During simulation, the line will have a subway starting at the
        beginning of the list, after which it proceeds to the right in the
        list. That is, if the line is [0, 1, 2], the train will start at
        station 0, then move to 1, to 2, back to 1, etc.

        Returns feedback from the simulation
        """
        self._sim_count = self._sim_count + 1
        if self._sim_count > SIM_ATTEMPTS:
            raise RuntimeError("Exceeded maximum allowed simulation runs. You may only call Game.simulate {} times.".format(SIM_ATTEMPTS))

        self.board.set_network(network)
        board_info = {
            'station_locations': self.getStationLocations(),
            'network': network
        }
        sim = Simulation(self.board, 
            start_time=0,
            duration=SIM_DURATION)
        states_list, passenger_stats = sim.run()

        feedback = Stats(passenger_stats)

        self.board_info = board_info
        self.states_list = states_list
        return feedback
    
    def visualize(self):
        if self.board_info is None or self.states_list is None:
            raise RuntimeWarning("Can't visualize since simulate has not been called yet.")
            return
        root = tk.Tk()
        window = Visualization(root,640, 480, self.board_info, self.states_list)
        root.after(0, window.run)
        root.mainloop()

        # TODO: Quit running tkinter window once visualization is finished