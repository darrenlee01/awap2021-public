"""
The Event and EventType classes establish a baseline for what events should
keep. All Events need to keep their the type and the timestep of occurrence.

This class also constructs all the subclasses necessary, including
PassengerEvent, ArrivalEvent, and DepartureEvent.
"""

from enum import Enum
from .passenger import Passenger

class EventType(Enum):
    """
    EventType is stored in an Event indicating the type of the Event. Although
    all actual events will be a subclass of Event, this is used for priority
    queue ordering, first ordering by time-step and this enum secondary.
    """
    SPAWN = 1
    ARRIVAL = 2
    DEPARTURE = 3

class Event:
    def __init__(self, time, typ):
        """ Base class. Stores its type and timestamp. """
        self.typ = typ
        self.time = time

    def __lt__(self, other):
        if(self.time == other.time):
            return self.typ.value <= other.typ.value
        return self.time < other.time


class PassengerEvent(Event):
    def __init__(self, id, time, shape, loc):
        """ Event for spawns. Keeps the passenger shape and init location. 
        loc: stationID """
        super().__init__(time, EventType.SPAWN)
        self.shape = shape
        self.loc = loc
        self.id = id

class ArrivalEvent(Event):
    def __init__(self, time, train, src, dest):
        """ Event for arrivals. Keeps the train ID and the src/dest. """
        super().__init__(time, EventType.ARRIVAL)
        self.train = train
        self.src = src
        self.dest = dest


class DepartureEvent(Event):
    def __init__(self, time, train, src, dest):
        """ Event for departures. Keeps the train ID and the src/dest. """
        super().__init__(time, EventType.DEPARTURE)
        self.train = train
        self.src = src
        self.dest = dest
