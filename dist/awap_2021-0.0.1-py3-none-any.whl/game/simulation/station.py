import numpy as np
import random

from .event import PassengerEvent

class Station:
    def __init__(self, station_id: int, shape_id: int, location_x: int, location_y: int, distribution_mean: int):
        self.UID = station_id
        self.shape = shape_id
        self.x = location_x
        self.y = location_y
        self.distribution_mean = distribution_mean
        self.passengers = [] # List of Passenger objects, in order of spawn
        self.next_passenger_id = 0

    def spawn_passengers(self, start_time, duration, num_shapes):
        """

        :param duration: Time period to generate spawns for in hours
        :return:
        """
        # Spawn passengers every 5 minutes
        spawns_per_hour = 12
        # Spawn distribution gives the number of passengers to spawn at the ith interval
        spawn_dist = np.random.poisson(self.distribution_mean, duration*spawns_per_hour)

        # Get shapes for of spawned passengers.
        # TODO: Should passengers go to the same shaped station they started at?
        # spawn_shapes = np.random.randint(0, num_shapes, np.sum(spawn_dist))
        shapes = list(range(0, num_shapes))
        shapes.remove(self.shape)
        spawn_shapes = random.choices(shapes, k = np.sum(spawn_dist))
        spawn_list = []

        for num_spawn in spawn_dist:
            n = round(num_spawn)
            for i in range(n):
                new_passenger = PassengerEvent((self.UID, self.next_passenger_id),
                                               start_time + 1/spawns_per_hour,
                                               spawn_shapes[self.next_passenger_id],
                                               self.UID)
                spawn_list.append(new_passenger)
                self.next_passenger_id += 1
        return spawn_list

    def get_passengers_for_train(self, train_color, num_passengers):
        """
        Get passengers at the station that should board a train. Picks the first
        `num_passengers` passengers from station's passengers list. 
        given the train color. 
        Sets current_route to chosen route for passengers traveling by the given 
        train
        :return: set of Passenger objects 
        """
        train_passengers = set()
        i = 0
        while i < num_passengers and i < len(self.passengers):
            passenger = self.passengers[i]
            if passenger.current_route is None:
                for route in passenger.routes:
                    if route[1] == train_color:
                        passenger.set_route(route)
                        train_passengers.add(passenger)
            elif passenger.current_route[1] == train_color:
                train_passengers.add(passenger)
            i = i + 1
        return train_passengers
    
    def add_passenger(self, passenger):
        self.passengers.append(passenger)
    
    def add_passengers(self, passengers_to_add):
        self.passengers.extend(passengers_to_add)
    
    def remove_passengers(self, passengers_to_rem):
        for p in passengers_to_rem:
            self.passengers.remove(p)