"""
The util class defines the importan enums Color and Shape for passengers,
subways, and stations to use.
"""

from enum import Enum, auto

NUM_SHAPES = 4
NUM_COLORS = 6
TRAIN_SPEED = 5
TRAIN_MINIMUM = 0
TRAIN_CAPACITY = 12
SIM_ATTEMPTS = 5
SPAWN_DURATION = 3
SIM_DURATION = 100

# TODO: Add more colors/shapes!
# MLK TODO: Replace this to be with images.
class Shape(Enum):
    CIRCLE = 0
    TRIANGLE = 1
    SQUARE = 2

class Color(Enum):
    #MLK TODO: use these colors http://www.science.smith.edu/dftwiki/index.php/Color_Charts_for_TKinter
    #MLK TODO: THEY MUST BE ONE WORD
    RED = 0
    BLUE = 1
    GREEN = 2
    YELLOW = 3
    PINK = 4
    LIGHTBLUE = 5

class PassengerStatus(Enum):
    SPAWNED = 1
    ON_TRAIN = 2
    IN_TRANSFER = 3